# VIDA — publicação Netlify | versão 1.1.0

## Conteúdo
- `index.html`: dashboard VIDA com Zelo Saúde.
- `netlify.toml`: diretório de publicação, sem comando de build.

## Para a primeira publicação automática
1. Vincule o site Netlify **existente** ao repositório GitHub.
2. Copie `index.html` e `netlify.toml` para a raiz do repositório.
3. Faça commit na branch de produção configurada no Netlify (habitualmente `main`).
4. Confirme o deploy em Netlify > Deploys e confira o URL https://vida-telemedicina.netlify.app/.

## Atenção
- Antes de atualizar, faça Backup JSON no painel atual para preservar alterações locais.
- Dados comerciais renegociados com a Zelo ainda dependem de minuta revisada.
- Este pacote NÃO foi enviado ao Netlify nem ao GitHub automaticamente.
